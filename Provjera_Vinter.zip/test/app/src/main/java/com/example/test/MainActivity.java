package com.example.test;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.view.View;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private EditText prviEdit;
    private TextView prviView;
    private ImageView slikaImageView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        prviEdit=findViewById(R.id.prviEdit);
        prviView=findViewById(R.id.prviView);
        slikaImageView=findViewById(R.id.slikaImageView);

    }

    public void clickPrviButton(View view)
    {
        String text="";
        text= prviEdit.getText().toString();
        prviView.setText(text);


    }

    public void clickDrugiButton(View view)
    {
        slikaImageView.setImageResource(R.drawable.manutd);
        Toast.makeText(getApplicationContext() , "MANUTD" , Toast.LENGTH_SHORT).show();

    }

    public void clickTreciButton(View view)
    {
        slikaImageView.setImageResource(R.drawable.osijek);
        Toast.makeText(getApplicationContext() , "OSIJEK" , Toast.LENGTH_SHORT).show();

    }



}